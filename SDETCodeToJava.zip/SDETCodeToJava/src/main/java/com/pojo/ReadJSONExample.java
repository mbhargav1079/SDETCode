package com.pojo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadJSONExample {

	public static void main(String[] args) {
		List<String> stateListP = readStateFromProperties();
	String stateName = stateListP.get(0);
	String abbr = stateListP.get(1);
		stateInfo(stateName,abbr);
		
	}
	
	public static boolean stateInfo(String stateName,String abbr) {

		
		boolean flag= false;
		String url = "http://services.groupkt.com/state/get/USA/all";
        Object obj = readDataFromRestServer(url);
		try {
		
           JSONObject jsonObject = (JSONObject)obj;
           Object object = jsonObject.get("RestResponse");
           JSONObject jsonObject1 = (JSONObject)object;
           
            JSONArray stateListArray = (JSONArray) jsonObject1.get("result");
            if(stateName!=null && !"".equalsIgnoreCase(stateName))
            	System.out.println("Given state from Properties file---"+stateName);
            else 
            	 System.out.println("Given abbr from Properties file---"+abbr);
           List<State> stateList = new ArrayList<State>();
			for (Object employee : stateListArray) {
				State state = parseStateObject((JSONObject)employee);
				stateList.add(state);
			}
			for(State s1 : stateList) {
				
				if(stateName!=null && stateName.equalsIgnoreCase(s1.getName()) ) {
					System.out.println("Largest city is------"+s1.getLargest_city());
					System.out.println("Capital is------"+s1.getCapital());
					flag=true;
					break;
				} else if(abbr!=null && abbr.equalsIgnoreCase(s1.getAbbr())){
					System.out.println("Largest city is------"+s1.getLargest_city());
					System.out.println("Capital is------"+s1.getCapital());
					flag=true;
					break;
				}
			}
        } catch (Exception e) {
            e.printStackTrace();
        } 
	return flag;
	}

	private static State parseStateObject(JSONObject employee) 
	{
		State state = new State();
		String id = employee.get("id").toString();
		state.setId(Integer.parseInt(id));
		state.setName(employee.get("name").toString());
		state.setCountry(employee.get("country").toString());
		state.setAbbr(employee.get("abbr").toString());
		state.setArea(employee.get("area").toString());
		if(employee.get("largest_city") !=null && employee.get("largest_city").toString() != null)
		state.setLargest_city(employee.get("largest_city").toString());
		else 
			state.setLargest_city("");
		state.setCapital(employee.get("capital").toString());
		
		
		
		return state;
	}
	
	public static Object readDataFromRestServer(String url) {
		Object obj = null;
		HttpURLConnection urlConn = null;
        BufferedReader reader = null;
        try {
            URL urlObj = new URL(url);
            urlConn = (HttpURLConnection) urlObj.openConnection();
            urlConn.setRequestMethod("GET");
            urlConn.setConnectTimeout(5000);
            urlConn.setReadTimeout(5000);
            urlConn.setRequestProperty("Accept", "application/json");
            if (urlConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                System.err.println("Unable to connect to the URL...");
                return obj;
            }
            System.out.println("Connected to the server...");
            InputStream is = urlConn.getInputStream();
            reader = new BufferedReader(new InputStreamReader((is)));
            System.out.println("Reading data from server...");
            JSONParser jsonParser = new JSONParser();
            String tmpStr = null;
            String tt = "";
            while((tmpStr = reader.readLine()) != null){
                tt =tt+tmpStr;
            }
            try {
				 obj = jsonParser.parse(tt);
			} catch (ParseException e) {
				e.printStackTrace();
			} 
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(reader != null) reader.close();
                if(urlConn != null) urlConn.disconnect();
            } catch(Exception ex){
                 
            }
        }
		return obj;
	}
	
	public static List<String> readStateFromProperties() {
		Properties prop = new Properties();
		InputStream input = null;
		List<String> stateList = new ArrayList<String>();
		try {
			String workingDir = System.getProperty("user.dir");
			input = new FileInputStream(workingDir+"\\state.properties");

			prop.load(input);

			stateList.add(prop.getProperty("state"));
			stateList.add(prop.getProperty("abbr"));
			

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return stateList;
	}
	
	

}
