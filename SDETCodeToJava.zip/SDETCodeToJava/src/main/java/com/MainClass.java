package com;

import java.io.FileReader;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import com.pojo.State;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		toJava();
	}
	public static void toJava() { 
		/*String sURL = "http://services.groupkt.com/state/get/USA/all"; //just a string
		String json = ClientBuilder.newClient().target("http://services.groupkt.com/state/get/USA/all").request().accept(MediaType.APPLICATION_JSON).get(State.class);

		 URL url;
		try {
			url = new URL(sURL);
			 URLConnection request = url.openConnection();
			 request.connect();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   */
		   
		// this is the key object to convert JSON to Java 
		ObjectMapper mapper = new ObjectMapper(); 
		JSONParser jsonParser = new JSONParser();

		try {
		//File json = new File("C:\\Users\\Chandra\\Downloads\\JSONSimpleExamples\\JSONSimpleExamples\\state.json"); 
		FileReader json = new FileReader("C:\\Users\\Chandra\\Downloads\\JSONSimpleExamples\\JSONSimpleExamples\\state.json");
		 Object obj = jsonParser.parse(json);

         JSONArray employeeList = (JSONArray) obj;
         System.out.println(employeeList);
		State cricketer = mapper.readValue(json, State.class); 
		System.out.println("Java object created from JSON String :"); 
		System.out.println(cricketer); 
		} catch (JsonGenerationException ex) {
			ex.printStackTrace(); 
			} catch (JsonMappingException ex) {
				ex.printStackTrace(); 
				} catch (IOException ex)		{ 
					ex.printStackTrace(); 
				} catch(Exception e) {
					
				}
		} 
}
